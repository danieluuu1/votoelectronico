package votoelectronico;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class SistemaVotoElectoralGUI {
    private SistemaVotoElectoral sistema;
    private JFrame frame;
    private JTable tableEstudiantes;
    private JTable tableCandidatos;
    private JTextField tfNombre;
    private JTextField tfCedula;
    private JComboBox<Curso> cbCurso;
    private JComboBox<Paralelo> cbParalelo;
    private JComboBox<Candidato> cbCandidatos;
    private JTextField tfVotanteCedula;

    public SistemaVotoElectoralGUI(SistemaVotoElectoral sistema) {
        this.sistema = sistema;
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Sistema de Voto Electrónico");
        frame.setBounds(100, 100, 1000, 700);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout());

        JTabbedPane tabbedPane = new JTabbedPane();
        frame.getContentPane().add(tabbedPane, BorderLayout.CENTER);

        // Panel para registro de estudiantes
        JPanel panelRegistro = new JPanel();
        tabbedPane.addTab("Registro", null, panelRegistro, null);
        panelRegistro.setLayout(new GridLayout(0, 2));

        panelRegistro.add(new JLabel("Nombre:"));
        tfNombre = new JTextField();
        panelRegistro.add(tfNombre);

        panelRegistro.add(new JLabel("Cédula:"));
        tfCedula = new JTextField();
        panelRegistro.add(tfCedula);

        panelRegistro.add(new JLabel("Curso:"));
        cbCurso = new JComboBox<>();
        panelRegistro.add(cbCurso);

        panelRegistro.add(new JLabel("Paralelo:"));
        cbParalelo = new JComboBox<>();
        panelRegistro.add(cbParalelo);

        JButton btnRegistrarEstudiante = new JButton("Registrar Estudiante");
        panelRegistro.add(btnRegistrarEstudiante);

        // Panel para mostrar candidatos
        JPanel panelCandidatos = new JPanel();
        tabbedPane.addTab("Candidatos", null, panelCandidatos, null);
        panelCandidatos.setLayout(new BorderLayout());

        tableCandidatos = new JTable(new DefaultTableModel(new Object[]{"ID", "Nombre", "Curso", "Paralelo"}, 0));
        panelCandidatos.add(new JScrollPane(tableCandidatos), BorderLayout.CENTER);

        // Panel para mostrar padrón electoral
        JPanel panelPadron = new JPanel();
        tabbedPane.addTab("Padrón Electoral", null, panelPadron, null);
        panelPadron.setLayout(new BorderLayout());

        tableEstudiantes = new JTable(new DefaultTableModel(new Object[]{"ID", "Nombre", "Curso", "Paralelo"}, 0));
        panelPadron.add(new JScrollPane(tableEstudiantes), BorderLayout.CENTER);

        // Panel para realizar votos
        JPanel panelVotacion = new JPanel();
        tabbedPane.addTab("Votación", null, panelVotacion, null);
        panelVotacion.setLayout(new GridLayout(0, 2));

        panelVotacion.add(new JLabel("Cédula del votante:"));
        tfVotanteCedula = new JTextField();
        panelVotacion.add(tfVotanteCedula);

        panelVotacion.add(new JLabel("Seleccionar Candidato:"));
        cbCandidatos = new JComboBox<>();
        panelVotacion.add(cbCandidatos);

        JButton btnVotar = new JButton("Votar");
        panelVotacion.add(btnVotar);

        // Agregar los eventos
        btnRegistrarEstudiante.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String nombre = tfNombre.getText();
                String cedula = tfCedula.getText();
                Curso curso = (Curso) cbCurso.getSelectedItem();
                Paralelo paralelo = (Paralelo) cbParalelo.getSelectedItem();

                if (nombre.isEmpty() || cedula.isEmpty() || curso == null || paralelo == null) {
                    JOptionPane.showMessageDialog(frame, "Todos los campos son obligatorios.");
                    return;
                }

                Estudiante estudiante = new Estudiante(cedula, nombre, curso, paralelo);
                sistema.agregarEstudiante(estudiante); // Llamar al método correcto
                actualizarTablaEstudiantes();
                actualizarComboBoxCandidatos();
            }
        });

        btnVotar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String cedulaVotante = tfVotanteCedula.getText();
                Candidato candidatoSeleccionado = (Candidato) cbCandidatos.getSelectedItem();

                if (cedulaVotante.isEmpty() || candidatoSeleccionado == null) {
                    JOptionPane.showMessageDialog(frame, "Todos los campos son obligatorios.");
                    return;
                }

                Estudiante estudianteVotante = sistema.getEstudiantes().stream()
                        .filter(est -> est.getId().equals(cedulaVotante)) // Asegurarse de que `est` es un `Estudiante`
                        .findFirst()
                        .orElse(null);

                if (estudianteVotante == null) {
                    JOptionPane.showMessageDialog(frame, "El estudiante no está registrado.");
                    return;
                }

                // Registrar el voto
                sistema.agregarVoto(cedulaVotante, candidatoSeleccionado);
                JOptionPane.showMessageDialog(frame, "Voto registrado para " + candidatoSeleccionado.getNombre());

                // Limpia el campo de cédula
                tfVotanteCedula.setText("");
            }
        });

        // Llenar los datos
        cargarDatos();

        frame.setVisible(true);
    }

    private void cargarDatos() {
        // Cargar cursos
        for (Curso curso : sistema.getCursos()) {
            cbCurso.addItem(curso);
        }

        // Cargar paralelos
        for (Paralelo paralelo : sistema.getParalelos()) {
            cbParalelo.addItem(paralelo);
        }

        // Cargar candidatos
        actualizarTablaCandidatos();
        actualizarComboBoxCandidatos();

        // Cargar estudiantes
        actualizarTablaEstudiantes();
    }

    private void actualizarTablaEstudiantes() {
        DefaultTableModel model = (DefaultTableModel) tableEstudiantes.getModel();
        model.setRowCount(0);

        for (Estudiante estudiante : sistema.getEstudiantes()) {
            model.addRow(new Object[]{estudiante.getId(), estudiante.getNombre(), estudiante.getCurso().getNombre(), estudiante.getParalelo().getNombre()});
        }
    }

    private void actualizarTablaCandidatos() {
        DefaultTableModel model = (DefaultTableModel) tableCandidatos.getModel();
        model.setRowCount(0);

        for (Candidato candidato : sistema.getCandidatos()) {
            model.addRow(new Object[]{candidato.getId(), candidato.getNombre(), candidato.getCurso().getNombre(), candidato.getParalelo().getNombre()});
        }
    }

    private void actualizarComboBoxCandidatos() {
        cbCandidatos.removeAllItems();
        for (Candidato candidato : sistema.getCandidatos()) {
            cbCandidatos.addItem(candidato);
        }
    }
}





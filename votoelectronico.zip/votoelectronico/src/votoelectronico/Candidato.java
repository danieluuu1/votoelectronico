package votoelectronico;

public class Candidato {
    private String id;
    private String nombre;
    private Curso curso;
    private Paralelo paralelo;

    // Constructor
    public Candidato(String id, String nombre, Curso curso, Paralelo paralelo) {
        this.id = id;
        this.nombre = nombre;
        this.curso = curso;
        this.paralelo = paralelo;
    }

    // Getters y Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Curso getCurso() {
        return curso;
    }

    public void setCurso(Curso curso) {
        this.curso = curso;
    }

    public Paralelo getParalelo() {
        return paralelo;
    }

    public void setParalelo(Paralelo paralelo) {
        this.paralelo = paralelo;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Nombre: " + nombre + ", Curso: " + curso.getNombre() + ", Paralelo: " + paralelo.getNombre();
    }
}



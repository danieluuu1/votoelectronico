package votoelectronico;

public class MesaElectoral {
    private String id;
    private String ubicacion;

    // Constructor
    public MesaElectoral(String id, String ubicacion) {
        this.id = id;
        this.ubicacion = ubicacion;
    }

    // Getters y Setters
    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public void setUbicacion(String ubicacion) {
        this.ubicacion = ubicacion;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Ubicación: " + ubicacion;
    }
}



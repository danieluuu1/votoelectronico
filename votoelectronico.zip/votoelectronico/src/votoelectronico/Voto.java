package votoelectronico;

public class Voto {
    private String cedulaEstudiante;
    private Candidato candidato;

    public Voto(String cedulaEstudiante, Candidato candidato) {
        this.cedulaEstudiante = cedulaEstudiante;
        this.candidato = candidato;
    }

    public String getCedulaEstudiante() {
        return cedulaEstudiante;
    }

    public void setCedulaEstudiante(String cedulaEstudiante) {
        this.cedulaEstudiante = cedulaEstudiante;
    }

    public Candidato getCandidato() {
        return candidato;
    }

    public void setCandidato(Candidato candidato) {
        this.candidato = candidato;
    }
}



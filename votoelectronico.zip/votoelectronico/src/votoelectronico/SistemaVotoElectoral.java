package votoelectronico;

import java.util.ArrayList;
import java.util.List;

public class SistemaVotoElectoral {
    private List<Curso> cursos;
    private List<Paralelo> paralelos;
    private List<Estudiante> estudiantes;
    private List<Candidato> candidatos;
    private List<Voto> votos;

    public SistemaVotoElectoral() {
        cursos = new ArrayList<>();
        paralelos = new ArrayList<>();
        estudiantes = new ArrayList<>();
        candidatos = new ArrayList<>();
        votos = new ArrayList<>();
    }

    public void agregarCurso(Curso curso) {
        cursos.add(curso);
    }

    public void agregarParalelo(Paralelo paralelo) {
        paralelos.add(paralelo);
    }

    public void agregarCandidato(Candidato candidato) {
        candidatos.add(candidato);
    }

    public void agregarEstudiante(Estudiante estudiante) {
        estudiantes.add(estudiante);
    }

    public void agregarVoto(String cedulaEstudiante, Candidato candidato) {
        votos.add(new Voto(cedulaEstudiante, candidato));
    }

    public List<Curso> getCursos() {
        return cursos;
    }

    public List<Paralelo> getParalelos() {
        return paralelos;
    }

    public List<Estudiante> getEstudiantes() {
        return estudiantes;
    }

    public List<Candidato> getCandidatos() {
        return candidatos;
    }
}







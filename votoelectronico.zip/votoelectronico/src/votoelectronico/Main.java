package votoelectronico;

import javax.swing.SwingUtilities;

public class Main {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            SistemaVotoElectoral sistema = new SistemaVotoElectoral();

            // Crear y registrar cursos y paralelos
            String[] nombresCursos = {"Primero", "Segundo", "Tercero", "Cuarto", "Quinto", "Sexto", "Séptimo", "Octavo", "Noveno", "Bachillerato"};
            String[] nombresParalelos = {"A", "B", "C"};

            for (String nombreCurso : nombresCursos) {
                Curso curso = new Curso(nombreCurso);
                sistema.agregarCurso(curso);
                for (String nombreParalelo : nombresParalelos) {
                    Paralelo paralelo = new Paralelo(nombreParalelo);
                    curso.agregarParalelo(paralelo);
                    sistema.agregarParalelo(paralelo);
                }
            }

            // Crear y registrar estudiantes y candidatos
            for (String nombreCurso : nombresCursos) {
                Curso curso = sistema.getCursos().stream()
                                    .filter(c -> c.getNombre().equals(nombreCurso))
                                    .findFirst()
                                    .orElse(null);

                if (curso != null) {
                    for (String nombreParalelo : nombresParalelos) {
                        Paralelo paralelo = sistema.getParalelos().stream()
                                                    .filter(p -> p.getNombre().equals(nombreParalelo))
                                                    .findFirst()
                                                    .orElse(null);

                        if (paralelo != null) {
                            Estudiante estudiante = new Estudiante("E" + nombreCurso.charAt(0) + nombreParalelo, "Estudiante " + nombreCurso + " " + nombreParalelo, curso, paralelo);
                            sistema.agregarEstudiante(estudiante);

                            Candidato candidato = new Candidato("C" + nombreCurso.charAt(0) + nombreParalelo, "Candidato " + nombreCurso + " " + nombreParalelo, curso, paralelo);
                            sistema.agregarCandidato(candidato);
                        }
                    }
                }
            }

            // Mostrar la interfaz gráfica
            new SistemaVotoElectoralGUI(sistema);
        });
    }
}




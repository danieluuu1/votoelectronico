package votoelectronico;

import java.util.List;

public class PadronElectoral {
    private List<Estudiante> estudiantes;

    // Constructor
    public PadronElectoral(List<Estudiante> estudiantes) {
        this.estudiantes = estudiantes;
    }

    // Método para visualizar el padrón electoral
    public void mostrarPadron() {
        if (estudiantes.isEmpty()) {
            System.out.println("El padrón electoral está vacío.");
            return;
        }
        for (Estudiante estudiante : estudiantes) {
            System.out.println(estudiante);
        }
    }
}


package votoelectronico;

import java.util.ArrayList;
import java.util.List;

public class Curso {
    private String nombre;
    private List<Paralelo> paralelos;

    // Constructor
    public Curso(String nombre) {
        this.nombre = nombre;
        this.paralelos = new ArrayList<>();
    }

    // Métodos para añadir paralelos
    public void agregarParalelo(Paralelo paralelo) {
        if (paralelo == null || paralelo.getNombre().isEmpty()) {
            throw new IllegalArgumentException("El paralelo no puede ser nulo y debe tener un nombre.");
        }
        this.paralelos.add(paralelo);
    }

    // Getters y Setters
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public List<Paralelo> getParalelos() {
        return paralelos;
    }

    @Override
    public String toString() {
        return "Curso: " + nombre;
    }
}


